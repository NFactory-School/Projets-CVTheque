-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  jeu. 15 nov. 2018 à 09:35
-- Version du serveur :  10.1.36-MariaDB
-- Version de PHP :  7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `nf_vax`
--

-- --------------------------------------------------------

--
-- Structure de la table `vax_contact`
--

CREATE TABLE `vax_contact` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `objet` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `created_at` datetime NOT NULL,
  `statut` enum('lu','non lu') NOT NULL DEFAULT 'non lu'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `vax_pivot`
--

CREATE TABLE `vax_pivot` (
  `id` int(11) NOT NULL,
  `id_profil` int(11) NOT NULL,
  `id_vaccins` int(11) NOT NULL,
  `date` date NOT NULL,
  `rappel` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `vax_profils`
--

CREATE TABLE `vax_profils` (
  `id` int(11) NOT NULL,
  `mail` varchar(155) NOT NULL,
  `mdp` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `modified_at` datetime DEFAULT NULL,
  `nom` varchar(255) DEFAULT NULL,
  `prenom` varchar(255) DEFAULT NULL,
  `ddn` date DEFAULT NULL,
  `sexe` enum('homme','femme','autre') DEFAULT NULL,
  `taille` int(11) DEFAULT NULL,
  `poids` int(11) DEFAULT NULL,
  `notif` enum('oui','non') DEFAULT 'non',
  `token` varchar(255) NOT NULL,
  `status` enum('admin','user','banni') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `vax_profils`
--

INSERT INTO `vax_profils` (`id`, `mail`, `mdp`, `created_at`, `modified_at`, `nom`, `prenom`, `ddn`, `sexe`, `taille`, `poids`, `notif`, `token`, `status`) VALUES
(31, 'novaedra@gmail.com', '$2y$10$.g.XDJOKKOSey46AEpuWxODMJ8obzun3yniwAdlXeVSZ490hG4Hp6', '2018-11-12 10:59:09', '2018-11-15 09:12:40', 'Fouquier', 'Léo', '0000-00-00', 'homme', 180, 60, 'oui', 'ItjwAtn470dnfDdq8VWFN5K0slcH1vVcRbp4RnQBCAkawdz3bb5F7DWvoop3QPV8snaU7RvS9LdrBksjdW7fnwRIb2n8vpp3fpFjGc7o8nsDuOEVQBlD7OYH', 'admin'),
(32, 'mathias@delp.fr', '$2y$10$h3vUmO/vYe/RyyfcJNO76.yPWrUC8hqcWZxpyVfTmsc/Ozg6EicSq', '2018-11-12 11:02:18', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'non', '63EEwndno33Eg54Krxk0drb1e7EB2Tg971tgliyYZNGPKWk0WCaAOGmgAzqcnvtUtEhMIsvcWLtjN01v6IKvljRNXGtHcBT5kHX9rVa3ExsB7aoxx2FEpYVI', 'admin'),
(33, 'admin@admin.fr', '$2y$10$hO0AKKhNJRGOcU6wVNmf7epdhbY6V0bU.Evh0NXerHjDujV0nLteu', '2018-11-12 11:03:34', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'non', 'tZ0BqOcuWcj2elIomTPWZ3mckEaAEEtNhEWbH6UFiRfQzwDqCD6NrKcjk1uxnQOhH6T3OpQ3uwkvDwzP830ozgfjuSDr8APDTUE6DSzx5TeIGmKsAqMNeRbh', 'admin'),
(34, 'niconzeweb@wanadoo.fr', '$2y$10$8tignnxqp/OmK8dQiYJE3Ot/3NcxNpOJgW31bJUIQVGRqOm3EEuF6', '2018-11-12 11:04:10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'non', 'BW0QGlTPMmdP2qcJNWbPeWtkYejXDCf2WLmQMJbENX9vd0T9oGaUSedX1r8G1zmAmPwvpzW4Fjq7DMiDkTBBkDMiC2o3eXISCwA1PSX7ScSiqvl92WnilcMl', 'admin'),
(37, 'user@gmail.com', '$2y$10$AJKSLvHkjgrEOcQkkYrK8ur8RJQljeFO9AbnEM31kwYYi5ENHeG3q', '2018-11-13 12:01:52', '2018-11-13 12:06:01', 'Fouquier', 'Léo', '0000-00-00', 'homme', 180, 60, 'oui', 'UmJ69B0JU9nCZFlEau6fqtLvFDsTAaxT2N8HPr3Aw7QYPWvAIuTmihORiDZ9NIvOOO7JrxDfhsK5jMKuJ6wFMoPns09oXAPEKWXwDHaUpXBQbcubKrGCR5ds', 'user');

-- --------------------------------------------------------

--
-- Structure de la table `vax_vaccins`
--

CREATE TABLE `vax_vaccins` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `maladie_cible` varchar(255) NOT NULL,
  `info` text NOT NULL,
  `age_recommande` int(11) NOT NULL,
  `status` enum('affiché','masqué') NOT NULL DEFAULT 'affiché',
  `obligatoire` enum('oui','non') NOT NULL DEFAULT 'non'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `vax_vaccins`
--

INSERT INTO `vax_vaccins` (`id`, `nom`, `maladie_cible`, `info`, `age_recommande`, `status`, `obligatoire`) VALUES
(9, 'DTP', 'Diphtérie, tétanos, poliomyélite ', 'Obligatoire dès la naissance.\r\n\r\nLes rappels de l\'adulte sont recommandés à âges fixes (25, 45, 65 ans puis tous les 10 ans).', 1, 'affiché', 'oui'),
(11, 'BCG', 'tuberculose', 'pour les enfants exposés à un risque élevé parmi lesquels :\r\n\r\n- enfants résidant en Île-de-France ou en Guyane\r\n\r\n- enfants à antécédents familiaux, nés ou issus de parents originaires d\'un pays très touché par la tuberculose, ou vivant dans un habitat précaire', 1, 'affiché', 'non'),
(12, 'Coqueluche', 'Coqueluche', 'Recommandée à l\'entourage du nourrisson si leur dernier rappel de la coqueluche date de plus de 10 ans', 2, 'affiché', 'oui'),
(13, 'Hépatite_B', 'Hépatite B', 'Si la vaccination n\'a pas été réalisée au cours de la 1 ère année de vie, elle peut être réalisée jusqu\'à 15 ans inclus.\r\n\r\nÀ partir de 16 ans, elle est recommandée uniquement chez les personnes exposées au risque de l\'hépatite B.', 2, 'affiché', 'oui'),
(14, 'Pneumocoque', 'Pneumocoque', 'PNEUMOVAX est un vaccin qui protège contre plus de types de pneumocoques. \r\nIl est réservé, en complément du vaccin classique, à certains enfants et adultes à risque : personnes dont la rate a été retirée, ou celles qui souffrent d’insuffisance cardiaque ou respiratoire', 2, 'affiché', 'oui'),
(15, 'Méningocoque', 'Méningocoque', 'rattrapage jusqu\'à 24 ans', 5, 'affiché', 'oui'),
(16, 'ROR', 'Rougeole, Oreillon, Rubéole', '2ème dose entre 16 et 18 mois', 12, 'affiché', 'oui'),
(17, 'Papillomavirus', 'Papillomavirus humains', 'Recommandée chez les jeunes filles de 11 à 14 ans avec un rattrapage jusqu\'à 19 ans inclus', 11, 'affiché', 'non'),
(18, 'Grippe', 'Grippe', 'Recommandée chaque année pour les personnes à risques y compris les enfants à partir de 6 mois, les femmes enceintes et les personnes âgées de 65 ans et plus', 6, 'affiché', 'non'),
(19, 'Zona', 'Zona', 'Recommandée chez les personnes âgées de 65 à 74 ans inclus.', 780, 'affiché', 'non'),
(20, 'HIB', 'Haemophilus influenzae de type b', 'Si, dans la famille d’un patient atteint d’une infection Hib invasive, il y a encore un enfant de moins de 4 ans, tous les membres de cette famille devront prendre des antibiotiques par mesure de prévention.\r\n\r\nLa vaccination contre Haemophilus influenzae type b est recommandée dans certaines situations à risque au delà de l\'âge de 5 ans : personnes immunodéprimées, splénectomisés, traitement par rituximab ou par anti-TNF Alpha.', 2, 'affiché', 'oui');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `vax_contact`
--
ALTER TABLE `vax_contact`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `vax_pivot`
--
ALTER TABLE `vax_pivot`
  ADD UNIQUE KEY `id` (`id`);

--
-- Index pour la table `vax_profils`
--
ALTER TABLE `vax_profils`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `mail` (`mail`);

--
-- Index pour la table `vax_vaccins`
--
ALTER TABLE `vax_vaccins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nom` (`nom`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `vax_contact`
--
ALTER TABLE `vax_contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `vax_pivot`
--
ALTER TABLE `vax_pivot`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT pour la table `vax_profils`
--
ALTER TABLE `vax_profils`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT pour la table `vax_vaccins`
--
ALTER TABLE `vax_vaccins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
